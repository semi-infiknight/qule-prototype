package com.Qule.FileUploadpkg;

public class MolProperty {
	private String natural_product_scores;
	private String quantitative_estimation_druglikeness_scores;
	private String water_octanol_partition_coefficient_scores;
	private String synthetic_accessibility_score_scores;
	
	public String getNatural_product_scores() {
		return natural_product_scores;
	}

	public void setNatural_product_scores(String natural_product_scores) {
		this.natural_product_scores = natural_product_scores;
	}

	public String getQuantitative_estimation_druglikeness_scores() {
		return quantitative_estimation_druglikeness_scores;
	}

	public void setQuantitative_estimation_druglikeness_scores(String quantitative_estimation_druglikeness_scores) {
		this.quantitative_estimation_druglikeness_scores = quantitative_estimation_druglikeness_scores;
	}

	public String getWater_octanol_partition_coefficient_scores() {
		return water_octanol_partition_coefficient_scores;
	}

	public void setWater_octanol_partition_coefficient_scores(String water_octanol_partition_coefficient_scores) {
		this.water_octanol_partition_coefficient_scores = water_octanol_partition_coefficient_scores;
	}

	public String getSynthetic_accessibility_score_scores() {
		return synthetic_accessibility_score_scores;
	}

	public void setSynthetic_accessibility_score_scores(String synthetic_accessibility_score_scores) {
		this.synthetic_accessibility_score_scores = synthetic_accessibility_score_scores;
	}

	public MolProperty() {
		
	}

	

}
